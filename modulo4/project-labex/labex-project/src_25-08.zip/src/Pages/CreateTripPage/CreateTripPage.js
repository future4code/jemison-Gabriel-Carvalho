import React from 'react';
import { Formulario, InputContainer, InputStyled, SelectedContainer } from '../ApplicationFormPage/ApplicationFormPageStyled';
import { Botoes, Main, Titulo } from '../HomePage/HomePageStyled';
import {useProtectedPage} from '../../hooks/useProtectedPage'
import useForm from '../../hooks/useForm';
import axios from 'axios';
import { URL } from '../../constants/Url';
import { ListPlanets } from '../../constants/Planets';
import { useNavigate } from 'react-router-dom';


function CreateTripPage () {
    useProtectedPage();

    const navigate = useNavigate();

    const [form, onChange] = useForm({
        name: "",
        date: "",
        description: "",
        durationInDays: Number(null),
        planet: ""
    })

    const createTrip = (e) => {
        e.preventDefault();
        const body = {
            name: form.name,
            date: form.date,
            description: form.description,
            durationInDays: form.durationInDays,
            planet: form.planet
        }

        const headers = {
            "content-type": "application/json",
            auth: localStorage.getItem("token")
        }
        
        axios.post(`${URL}/trips`, body, headers)
        .then((response) => {alert('Viagem criada!')})
        .catch((error) => {console.log(error)})
    }

    const voltar = () =>{
        navigate(-1)
    }

    
    return(
        <Main>
            <Titulo> Criar viagem</Titulo>
            <Formulario onSubmit={createTrip}>
                <InputContainer >
                    <label htmlFor="name">
                        <InputStyled 
                            id="name"
                            placeholder='Nome'
                            name="name"
                            type="text" 
                            value={form.name}
                            onChange={onChange}
                            pattern={"^.{10,}"}
                            required
                        />
                    </label>
                </InputContainer>

                <InputContainer >
                    <label  name="date" htmlFor="date">
                        <InputStyled 
                            id="date"
                            name="date"
                            type="date" 
                            onChange={onChange}
                            required
                        />
                    </label>
                </InputContainer>

                <InputContainer >
                    <label htmlFor="description">
                        <InputStyled 
                            id="description"
                            placeholder='Descrição da viagem'
                            name="description"
                            type="text" 
                            value={form.description}
                            onChange={onChange}
                            required
                        />
                    </label>
                </InputContainer>

                <InputContainer >
                    <label htmlFor="durationInDays">
                        Duração
                        <InputStyled 
                            placeholder='Duração em dias'
                            id="durationInDays"
                            name="durationInDays"
                            type="text" 
                            value={form.durationInDays}
                            onChange={onChange}
                            required
                        />
                    </label>
                </InputContainer>

                <SelectedContainer> 
                    <select name="Planet" onChange={onChange}>
                        {ListPlanets}
                    </select>
                </SelectedContainer>

                <Botoes>
                    <button onClick={voltar}>voltar</button>
                    <button>criar</button>
                </Botoes>
            </Formulario>
        </Main>
    )
}

export default CreateTripPage;