import styled from "styled-components";

export const ListContainer = styled.div `
    width: 100%;
    height: 100%;
    background-color: lightgray;
`